define(function() {var keywords=[{w:"Become",p:["p0"]},{w:"a",p:["p0","p1"]},{w:"Member",p:["p0","p1"]},{w:"of",p:["p0","p1"]},{w:"the",p:["p0","p1"]},{w:"USCA",p:["p0"]},{w:"Register",p:["p1","p3"]},{w:"as",p:["p1","p3"]},{w:"Dakota",p:["p1"]},{w:"Curling",p:["p1"]},{w:"Club",p:["p1"]},{w:"Fill",p:["p2"]},{w:"out",p:["p2"]},{w:"Player",p:["p2","p3"]},{w:"Registration",p:["p2"]},{w:"Google",p:["p2"]},{w:"Form",p:["p2"]},{w:"U.S.",p:["p3"]},{w:"College",p:["p3"]},{w:"Tour",p:["p3"]},{w:"Reporting",p:["p4"]},{w:"Merit",p:["p4"]},{w:"Points",p:["p4"]}];
var ph={};
ph["p0"]=[0, 1, 2, 3, 4, 5];
ph["p1"]=[6, 7, 1, 2, 3, 4, 8, 9, 10];
ph["p2"]=[11, 12, 13, 14, 15, 16];
ph["p3"]=[6, 7, 17, 18, 19, 13];
ph["p4"]=[20, 21, 22];
     return {
         keywords: keywords,
         ph: ph
     }
});
