/*Maps current topic to its parent: "topicIndex:parentIndex". -1 represents the map.*/
define(function () {
return {0:3,2:3,4:-1,1:0,3:-1};
});