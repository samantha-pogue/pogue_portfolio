/**
 * Load the libraries for the Index Terms page.
 */
define(["require", "config"], function() {
    require([
        'polyfill',
        'menu',
        'expand',
        'template-module-loader'
    ]);
});